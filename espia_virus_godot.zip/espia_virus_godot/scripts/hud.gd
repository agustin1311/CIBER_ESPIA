extends Node2D
## HUD, menú principal y pantallas de nivel completado / game over / victoria.

const Util = preload("res://scripts/util.gd")
const SW := 1280.0
const SH := 720.0

var game  # referencia a game.gd (se asigna desde Game._ready)


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if game == null:
		return
	if game.state == game.State.MENU:
		_draw_menu()
		return

	_draw_hud()
	var cx := SW / 2.0
	if game.state == game.State.LEVEL_DONE or game.hacked:
		draw_rect(Rect2(0, 0, SW, SH), Color8(0, 20, 10, 140))
		Util.text_center(self, "VIRUS IMPLANTADO", cx, 230, 60, Color8(90, 255, 140))
		Util.text_center(self, "%s ha sido comprometido" % game.team().name, cx, 310, 28, Color.WHITE)
		if game.state == game.State.LEVEL_DONE:
			var msg := "[ENTER] terminar misión" if game.level >= 2 else "[ENTER] siguiente objetivo"
			Util.text_center(self, msg, cx, 380, 24, Color8(255, 255, 255, 220))
	if game.state == game.State.GAME_OVER:
		draw_rect(Rect2(0, 0, SW, SH), Color8(40, 0, 0, 170))
		Util.text_center(self, "ESPÍA DESCUBIERTA", cx, 250, 64, Color8(255, 80, 100))
		Util.text_center(self, "Puntos: %d" % game.score, cx, 340, 28, Color.WHITE)
		Util.text_center(self, "[ENTER] volver al menú", cx, 400, 24, Color.WHITE)
	if game.state == game.State.VICTORY:
		draw_rect(Rect2(0, 0, SW, SH), Color8(0, 10, 40, 190))
		Util.text_center(self, "MISIÓN CUMPLIDA", cx, 220, 70, Color8(90, 230, 255))
		Util.text_center(self, "Los 3 equipos enemigos están infectados", cx, 310, 28, Color.WHITE)
		Util.text_center(self, "Puntuación final: %d" % game.score, cx, 360, 30, Color8(90, 255, 140))
		Util.text_center(self, "[ENTER] volver al menú", cx, 430, 24, Color.WHITE)


func _draw_menu() -> void:
	var cx := SW / 2.0
	Util.text_center(self, "CYBER ESPÍA", cx, 120, 80, Color8(90, 230, 255))
	Util.text_center(self, "OPERACIÓN VIRUS", cx, 205, 50, Color8(255, 110, 200))
	Util.text_center(self, "Infíltrate en las bases enemigas e implanta el virus cibernético", cx, 290, 22, Color.WHITE)
	var blink: float = clampf((160.0 + sin(game.time * 5.0) * 90.0) / 255.0, 0.0, 1.0)
	Util.text_center(self, "[ENTER] para comenzar", cx, 520, 30, Color(90.0 / 255.0, 1.0, 140.0 / 255.0, blink))
	var t: Texture2D = game.tex_front
	if t != null:
		var h := 260.0
		var w: float = h * t.get_width() / t.get_height()
		draw_texture_rect(t, Rect2(cx - w / 2.0, 320, w, h), false)


func _draw_hud() -> void:
	var g = game
	var tm: Dictionary = g.team()
	var tcol: Color = tm.col
	draw_rect(Rect2(0, 0, SW, 84), Color8(0, 0, 0, 120))
	Util.bar(self, 20, 14, 260, g.hp / 100.0, Color8(255, 80, 110), "SALUD")
	Util.bar(self, 20, 40, 260, g.energy / 100.0, Color8(90, 220, 255), "SIGILO")

	var alive := 0
	var inf := 0
	for e in g.enemies:
		if e.alive:
			alive += 1
			if e.infected:
				inf += 1
	Util.text(self, "OBJETIVO: %s  (%s)" % [tm.name, tm.corp], 400, 14, 22, tcol)
	Util.text(self, "Enemigos: %d   Infectados: %d   Misión %d/3" % [alive, inf, g.level + 1], 400, 44, 18, Color.WHITE)
	Util.text(self, "PUNTOS %06d" % g.score, SW - 240, 14, 24, Color8(90, 255, 140))
	var dist: float = maxf(0.0, g.terminal.x - g.pl_pos.x)
	Util.text(self, "Servidor a %d m" % int(dist / 40.0), SW - 240, 46, 18, Color.WHITE)
	Util.text(self, "A/D mover  W/ESPACIO saltar  J/clic disparar virus  SHIFT sigilo  E hackear servidor", 20, SH - 28, 16, Color8(200, 220, 255, 190))

	if g.msg_timer > 0.0:
		var a := minf(1.0, g.msg_timer)
		Util.text_center(self, "INFILTRACIÓN: %s" % tm.name, SW / 2.0, 150, 40, Color(tcol.r, tcol.g, tcol.b, a))
		Util.text_center(self, "Infecta a los guardias, llega al servidor e implanta el virus", SW / 2.0, 200, 20, Color(1, 1, 1, a))
