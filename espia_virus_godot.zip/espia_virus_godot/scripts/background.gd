extends Node2D
## Fondo en espacio de pantalla (CanvasLayer -1): degradado, luna neón,
## edificios con parallax y lluvia de código binario.

const Util = preload("res://scripts/util.gd")
const SW := 1280.0
const SH := 720.0

var game  # referencia a game.gd (se asigna desde Game._ready)


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	if game == null:
		return
	var time: float = game.time
	var cam_x: float = game.cam_x
	var team_col: Color = game.team().col

	# cielo (degradado vertical)
	var top := Color8(6, 8, 28)
	var bottom := Color8(28, 18, 60)
	draw_polygon(
		PackedVector2Array([Vector2(0, 0), Vector2(SW, 0), Vector2(SW, SH), Vector2(0, SH)]),
		PackedColorArray([top, top, bottom, bottom]))

	# luna / sol neón
	draw_circle(Vector2(980, 150), 60.0, Color8(255, 120, 200, 40))
	draw_circle(Vector2(980, 150), 36.0, Color8(255, 150, 220, 90))

	# edificios en 3 capas con parallax
	for l in 3:
		var f := 0.15 + l * 0.2
		var bw := 120.0 + l * 20.0
		var base := Color8(14 + l * 10, 16 + l * 12, 44 + l * 14)
		var first := int(floor(cam_x * f / bw)) - 1
		for i in range(first, first + int(SW / bw) + 4):
			var h := Util.hash2(i, l)
			var w := bw * 0.7 + (h % 40)
			var hgt := 120.0 + l * 40.0 + float((h >> 8) % (180 + l * 40))
			var x := i * bw - cam_x * f
			var y := 560.0 - hgt + l * 20.0
			draw_rect(Rect2(x, y, w, SH - y), base)
			draw_rect(Rect2(x, y, w, 3), team_col)
			# ventanas (índices relativos al edificio: no parpadean al mover la cámara)
			var wy := y + 14.0
			var row := 0
			while wy < 540.0:
				var wx := x + 8.0
				var col := 0
				while wx < x + w - 8.0:
					if Util.hash2(col + i * 31, row + l) % 5 == 0:
						draw_rect(Rect2(wx, wy, 6, 8), Color8(80, 220, 255, 70 + l * 30))
					wx += 14.0
					col += 1
				wy += 18.0
				row += 1

	# lluvia de código
	for i in 40:
		var x := fmod(float(i * 97 + Util.hash2(i, 7) % 50), SW)
		var y := fmod(time * (60 + Util.hash2(i, 3) % 90) + Util.hash2(i, 9) % 700, SH + 40.0) - 20.0
		var ch := "1" if (Util.hash2(i, int(time * 3.0)) & 1) == 1 else "0"
		Util.text(self, ch, x, y, 14, Color8(60, 255, 140, 45))
