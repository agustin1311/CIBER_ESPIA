extends RefCounted
## Utilidades de dibujo compartidas. Se usa con:
##   const Util = preload("res://scripts/util.gd")

static func text(ci: CanvasItem, s: String, x: float, y: float, size: int, col: Color) -> void:
	# y = borde superior del texto (como DrawText de raylib)
	var f: Font = ThemeDB.fallback_font
	ci.draw_string(f, Vector2(x, y + size * 0.85), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


static func text_center(ci: CanvasItem, s: String, cx: float, y: float, size: int, col: Color) -> void:
	var f: Font = ThemeDB.fallback_font
	var w: float = f.get_string_size(s, HORIZONTAL_ALIGNMENT_LEFT, -1, size).x
	ci.draw_string(f, Vector2(cx - w / 2.0, y + size * 0.85), s, HORIZONTAL_ALIGNMENT_LEFT, -1, size, col)


static func ellipse(ci: CanvasItem, c: Vector2, rx: float, ry: float, col: Color) -> void:
	ci.draw_set_transform(c, 0.0, Vector2(rx, ry))
	ci.draw_circle(Vector2.ZERO, 1.0, col)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


static func bar(ci: CanvasItem, x: float, y: float, w: float, frac: float, col: Color, label: String) -> void:
	ci.draw_rect(Rect2(x, y, w, 16), Color8(0, 0, 0, 160))
	ci.draw_rect(Rect2(x + 2, y + 2, (w - 4) * clampf(frac, 0.0, 1.0), 12), col)
	ci.draw_rect(Rect2(x, y, w, 16), Color8(255, 255, 255, 140), false, 1.0)
	text(ci, label, x + w + 8, y, 16, Color.WHITE)


## Hash determinista de 32 bits (equivalente al Hash() del original en C++).
static func hash2(a: int, b: int) -> int:
	var h: int = (((a & 0xFFFFFFFF) * 73856093) & 0xFFFFFFFF) ^ (((b & 0xFFFFFFFF) * 19349663) & 0xFFFFFFFF)
	h = h ^ (h >> 13)
	h = (h * 0x5bd1e995) & 0xFFFFFFFF
	h = h ^ (h >> 15)
	return h
