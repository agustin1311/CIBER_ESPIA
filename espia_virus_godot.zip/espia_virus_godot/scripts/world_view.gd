extends Node2D
## Dibuja el mundo del juego (se mueve con la Camera2D).

const Util = preload("res://scripts/util.gd")

var game  # referencia a game.gd (se asigna desde Game._ready)


func _process(_delta: float) -> void:
	if game == null:
		return
	visible = game.state != game.State.MENU
	queue_redraw()


func _draw() -> void:
	if game == null or game.state == game.State.MENU:
		return
	var g = game
	var tc: Color = g.team().col
	var w: float = g.level_w
	var gy: float = g.GROUND_Y

	# suelo
	draw_rect(Rect2(0, gy, w, 200), Color8(10, 12, 26))
	draw_rect(Rect2(0, gy, w, 3), tc)
	for x in range(0, int(w), 80):
		draw_line(Vector2(x, gy), Vector2(x, gy + 200), Color8(40, 60, 110, 120))
	for y in range(int(gy) + 30, int(gy) + 200, 40):
		draw_line(Vector2(0, y), Vector2(w, y), Color8(40, 60, 110, 90))

	# plataformas flotantes
	for i in range(1, g.plats.size()):
		var r: Rect2 = g.plats[i]
		draw_rect(r, Color8(20, 26, 52))
		draw_rect(Rect2(r.position.x, r.position.y, r.size.x, 3), Color8(80, 230, 255))

	_draw_terminal()
	for e in g.enemies:
		if e.alive:
			_draw_enemy(e)
	_draw_player()

	# balas
	for b in g.bullets:
		var c: Color = Color8(90, 255, 140) if b.friendly else Color8(255, 90, 90)
		var faded := Color(c.r, c.g, c.b, 0.35)
		draw_circle(b.p - b.v * 0.012, 4.0, faded)
		draw_circle(b.p, 6.0, faded)
		Util.text(self, "01" if b.friendly else "!!", b.p.x - 7, b.p.y - 6, 12, c)

	# partículas
	for p in g.parts:
		var col: Color = p.col
		col.a = clampf(p.life, 0.0, 1.0)
		Util.text(self, p.c, p.p.x, p.p.y, 16, col)


func _draw_player() -> void:
	var g = game
	var t: Texture2D = g.tex_front
	var moving: bool = absf(g.pl_vel.x) > 1.0 and g.on_ground
	if g.cloak:
		t = g.tex_helmet
	elif moving:
		t = g.tex_side

	var h := 120.0
	var bob := absf(sin(g.anim)) * 5.0 if moving else 0.0
	var a := 1.0
	if g.invul > 0.0 and int(g.time * 20.0) % 2 == 1:
		a = 0.35
	var pos: Vector2 = g.pl_pos

	Util.ellipse(self, pos, 26.0, 6.0, Color(0, 0, 0, 0.35))   # sombra
	if g.cloak:
		a = 0.6
		draw_arc(Vector2(pos.x, pos.y - 60.0), 62.0 + sin(g.time * 8.0) * 3.0, 0.0, TAU, 48, Color8(90, 230, 255, 120), 1.5)

	if t == null:
		draw_rect(g.p_rect(), Color.SKY_BLUE)
		return
	var wd: float = h * t.get_width() / t.get_height()
	# la vista lateral mira a la izquierda; las demás son simétricas
	var flip: bool = (g.facing > 0) if t == g.tex_side else (g.facing < 0)
	draw_set_transform(Vector2(pos.x, 0.0), 0.0, Vector2(-1.0 if flip else 1.0, 1.0))
	draw_texture_rect(t, Rect2(-wd / 2.0, pos.y - h - bob, wd, h), false, Color(1, 1, 1, a))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_enemy(e) -> void:
	var g = game
	var c: Color = g.team().col
	var r: Rect2 = g.e_rect(e)
	var body: Color = Color8(40, 190, 100) if e.infected else c
	if e.flash > 0.0:
		body = Color.WHITE
	var jx := 0.0
	if e.infected:
		jx = float(randi_range(-3, 3))   # efecto glitch
	var green := Color.GREEN
	var red := Color8(255, 70, 70)

	Util.ellipse(self, Vector2(e.x, g.GROUND_Y if e.t == g.EType.DRONE else e.y), 22.0, 5.0, Color(0, 0, 0, 0.31))

	if e.t == g.EType.GUARD:
		var d: int = e.dir
		draw_rect(Rect2(r.position.x + 6 + jx, r.position.y + 22, 24, 38), body)                 # torso
		draw_rect(Rect2(r.position.x + 4 + jx, r.position.y + 58, 12, 16), Color8(30, 30, 40))    # piernas
		draw_rect(Rect2(r.position.x + 20 + jx, r.position.y + 58, 12, 16), Color8(30, 30, 40))
		draw_rect(Rect2(r.position.x + 7 + jx, r.position.y + 2, 22, 22), Color8(40, 44, 58))     # casco
		var vx := 17.0 if d > 0 else 7.0
		draw_rect(Rect2(r.position.x + vx + jx, r.position.y + 9, 12, 6), green if e.infected else red)   # visor
		var ax := 24.0 if d > 0 else -8.0
		draw_rect(Rect2(r.position.x + ax + jx, r.position.y + 34, 20, 6), Color8(20, 20, 24))    # arma
	elif e.t == g.EType.DRONE:
		Util.ellipse(self, Vector2(e.x, e.y), 26.0, 15.0, body)
		Util.ellipse(self, Vector2(e.x, e.y + 3), 14.0, 7.0, Color8(25, 25, 35))
		draw_circle(Vector2(e.x, e.y), 5.0, green if e.infected else Color.RED)
		var w := sin(g.time * 50.0) * 20.0
		var rotor := Color8(200, 200, 210, 200)
		draw_rect(Rect2(e.x - 30 - w / 2.0, e.y - 20, 20 + w / 2.0, 3), rotor)
		draw_rect(Rect2(e.x + 10, e.y - 20, 20 + w / 2.0, 3), rotor)
	else:
		draw_rect(Rect2(r.position.x + 4, r.position.y + 22, 48, 24), Color8(36, 38, 50))
		draw_rect(Rect2(r.position.x + 12, r.position.y + 6, 32, 20), body)
		var bx: float = e.x - 3.0 if e.dir >= 0 else e.x + 3.0 - 34.0
		draw_rect(Rect2(bx, r.position.y + 12, 34, 6), Color8(20, 20, 24))   # cañón
		draw_circle(Vector2(e.x, r.position.y + 16), 4.0, green if e.infected else Color.RED)

	if e.infected:   # etiqueta de infección
		draw_rect(Rect2(r.position.x, r.position.y - 10, r.size.x * (e.inf_time / 6.0), 4), green)
		Util.text(self, "VIRUS", r.position.x, r.position.y - 26, 12, green)
	elif e.infect > 0.0:
		draw_rect(Rect2(r.position.x, r.position.y - 10, r.size.x * e.infect, 4), Color8(90, 255, 140, 200))


func _draw_terminal() -> void:
	var g = game
	var tc: Color = g.team().col
	var x: float = g.terminal.x
	var y: float = g.terminal.y
	var scr: Color = Color8(40, 220, 110) if g.hacked else tc

	draw_rect(Rect2(x - 50, y - 120, 100, 120), Color8(25, 28, 44))
	draw_rect(Rect2(x - 50, y - 120, 100, 120), scr, false, 1.0)
	draw_rect(Rect2(x - 40, y - 108, 80, 56), Color8(5, 8, 16))
	Util.text(self, "INFECTADO" if g.hacked else "SERVIDOR", x - 38, y - 98, 14, scr)
	Util.text(self, "0110 1001" if g.hacked else "ACCESO", x - 38, y - 78, 12, scr)
	for i in 4:
		var on: bool = (int(g.time * 4.0) + i) % 4 == 0
		draw_circle(Vector2(x - 30 + i * 16, y - 36), 4.0, scr if on else Color8(60, 60, 80))

	if (not g.hacked) and g.near_terminal():
		Util.text(self, "[E] IMPLANTAR VIRUS", x - 80, y - 150, 18, Color.WHITE)
		draw_rect(Rect2(x - 60, y - 135, 120, 10), Color8(20, 20, 30))
		draw_rect(Rect2(x - 60, y - 135, 120.0 * g.hack_prog, 10), Color8(90, 255, 140))
		draw_rect(Rect2(x - 60, y - 135, 120, 10), Color.WHITE, false, 1.0)
