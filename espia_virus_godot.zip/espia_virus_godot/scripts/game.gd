extends Node2D
## CYBER ESPÍA: OPERACIÓN VIRUS — port a Godot 4 (GDScript)
## Lógica del juego: estados, nivel, jugador, enemigos, balas y hackeo.
## El dibujo vive en world_view.gd, background.gd y hud.gd.

const SW := 1280
const SH := 720
const GRAVITY := 1700.0
const GROUND_Y := 620.0

enum State { MENU, PLAY, LEVEL_DONE, GAME_OVER, VICTORY }
enum EType { GUARD, DRONE, TURRET }

var teams := [
	{"name": "EQUIPO CRIMSON", "corp": "Crimson Corp", "col": Color8(235, 65, 75)},
	{"name": "EQUIPO SOLARIS", "corp": "Solaris Labs", "col": Color8(245, 190, 45)},
	{"name": "EQUIPO NOVA", "corp": "Nova Grid", "col": Color8(175, 95, 255)},
]


class Bullet:
	var p := Vector2.ZERO
	var v := Vector2.ZERO
	var friendly := false
	var alive := true
	var life := 2.2


class Particle:
	var p := Vector2.ZERO
	var v := Vector2.ZERO
	var life := 1.0
	var c := "0"
	var col := Color.WHITE


class Enemy:
	var t := 0                # EType
	var x := 0.0
	var y := 0.0
	var base_y := 0.0
	var min_x := 0.0
	var max_x := 0.0
	var dir := 1
	var infect := 0.0
	var inf_time := 0.0
	var infected := false
	var alive := true
	var cd := 1.0
	var phase := 0.0
	var flash := 0.0


# --- Estado general ---
var state: int = State.MENU
var level := 0
var score := 0
var level_w := 3600.0
var hack_prog := 0.0
var hacked_timer := 0.0
var msg_timer := 0.0
var hacked := false
var time := 0.0
var cam_x := SW / 2.0
var terminal := Vector2(0.0, GROUND_Y)

# --- Jugador (pl_pos = pies, centro-abajo) ---
var pl_pos := Vector2(150.0, GROUND_Y)
var pl_vel := Vector2.ZERO
var on_ground := true
var facing := 1
var hp := 100.0
var energy := 100.0
var cloak := false
var cloak_lock := 0.0
var invul := 0.0
var shoot_cd := 0.0
var anim := 0.0

# --- Mundo ---
var plats: Array = []      # Array de Rect2 (el índice 0 es el suelo)
var enemies: Array = []    # Array de Enemy
var bullets: Array = []    # Array de Bullet
var parts: Array = []      # Array de Particle

var tex_front: Texture2D
var tex_side: Texture2D
var tex_helmet: Texture2D

@onready var camera: Camera2D = $Camera


func _ready() -> void:
	randomize()
	tex_front = load("res://assets/front.png")
	tex_side = load("res://assets/side.png")
	tex_helmet = load("res://assets/helmet.png")
	camera.position = Vector2(SW / 2.0, 400.0)
	$World.game = self
	$Background/BackgroundDraw.game = self
	$HUDLayer/HUD.game = self


func team() -> Dictionary:
	return teams[level % 3]


# ------------------------------------------------------------------
#  Inicio y construcción de niveles
# ------------------------------------------------------------------
func start_game() -> void:
	level = 0
	score = 0
	hp = 100.0
	energy = 100.0
	cloak = false
	cloak_lock = 0.0
	invul = 0.0
	shoot_cd = 0.0
	facing = 1
	cam_x = SW / 2.0
	build_level()
	state = State.PLAY


func build_level() -> void:
	level_w = 3400.0 + level * 700.0
	plats.clear()
	enemies.clear()
	bullets.clear()
	parts.clear()
	hack_prog = 0.0
	hacked = false
	hacked_timer = 0.0
	pl_pos = Vector2(150.0, GROUND_Y)
	pl_vel = Vector2.ZERO
	on_ground = true
	hp = minf(100.0, hp + 40.0)
	energy = 100.0

	plats.append(Rect2(0.0, GROUND_Y, level_w, 200.0))   # suelo
	# Plataformas flotantes
	var px := 500.0
	while px < level_w - 700.0:
		var py := GROUND_Y - randf_range(110.0, 230.0)
		plats.append(Rect2(px, py, randf_range(150.0, 260.0), 16.0))
		px += randf_range(380.0, 560.0)
	terminal = Vector2(level_w - 220.0, GROUND_Y)

	# Enemigos
	var n := 7 + level * 4
	for i in n:
		var e := Enemy.new()
		var x := 650.0 + (level_w - 1300.0) * (i + randf_range(0.0, 0.8)) / n
		var r := randi_range(0, 9)
		e.x = x
		e.cd = randf_range(0.5, 1.5)
		e.phase = randf_range(0.0, 6.0)
		if r < 5:                                  # guardia
			e.t = EType.GUARD
			e.y = GROUND_Y
			e.min_x = x - 160.0
			e.max_x = x + 160.0
			if randi_range(0, 2) == 0:             # a veces sobre una plataforma
				for k in range(1, plats.size()):
					var pr: Rect2 = plats[k]
					if x > pr.position.x and x < pr.end.x:
						e.y = pr.position.y
						e.min_x = pr.position.x + 20.0
						e.max_x = pr.end.x - 20.0
						break
		elif r < 8:                                # dron
			e.t = EType.DRONE
			e.base_y = GROUND_Y - randf_range(200.0, 330.0)
			e.y = e.base_y
			e.min_x = x - 260.0
			e.max_x = x + 260.0
		else:                                      # torreta
			e.t = EType.TURRET
			e.y = GROUND_Y
			e.min_x = x
			e.max_x = x
		enemies.append(e)

	# Guardianes junto al servidor
	for i in 2 + level:
		var g := Enemy.new()
		g.t = EType.GUARD
		g.x = level_w - 480.0 + i * 90.0
		g.y = GROUND_Y
		g.min_x = g.x - 60.0
		g.max_x = g.x + 60.0
		g.cd = randf_range(0.5, 1.5)
		enemies.append(g)

	msg_timer = 3.5


# ------------------------------------------------------------------
#  Utilidades
# ------------------------------------------------------------------
func e_rect(e: Enemy) -> Rect2:
	match e.t:
		EType.GUARD:
			return Rect2(e.x - 18.0, e.y - 74.0, 36.0, 74.0)
		EType.DRONE:
			return Rect2(e.x - 26.0, e.y - 18.0, 52.0, 36.0)
		_:
			return Rect2(e.x - 28.0, e.y - 46.0, 56.0, 46.0)


func p_rect() -> Rect2:
	return Rect2(pl_pos.x - 20.0, pl_pos.y - 104.0, 40.0, 104.0)


func e_center(e: Enemy) -> Vector2:
	return e_rect(e).get_center()


func burst(p: Vector2, n: int, c: Color) -> void:
	for i in n:
		var pt := Particle.new()
		pt.p = p
		pt.v = Vector2(randf_range(-140.0, 140.0), randf_range(-220.0, -20.0))
		pt.life = randf_range(0.5, 1.2)
		pt.c = str(randi_range(0, 1))
		pt.col = c
		parts.append(pt)


func fire(from: Vector2, to: Vector2, friendly: bool, speed: float) -> void:
	var d := to - from
	var dist := maxf(d.length(), 1.0)
	var b := Bullet.new()
	b.p = from
	b.v = d / dist * speed
	b.friendly = friendly
	bullets.append(b)


func apply_infection(e: Enemy, amount: float) -> void:
	if e.infected or not e.alive:
		return
	e.infect += amount
	e.flash = 0.25
	score += 10
	burst(e_center(e), 6, Color8(90, 255, 140))
	if e.infect >= 1.0:
		e.infected = true
		e.inf_time = 6.0
		score += 50


func can_see(e: Enemy) -> bool:
	if cloak:
		return false
	var dx := absf(pl_pos.x - e.x)
	var dy := absf((pl_pos.y - 50.0) - e_center(e).y)
	return dx < 560.0 and dy < 300.0


func near_terminal() -> bool:
	return absf(pl_pos.x - terminal.x) < 90.0 and on_ground


# ------------------------------------------------------------------
#  Bucle principal
# ------------------------------------------------------------------
func _process(delta: float) -> void:
	var dt := minf(delta, 0.05)
	time += dt

	match state:
		State.MENU:
			cam_x = SW / 2.0
			camera.position = Vector2(cam_x, 400.0)
			if Input.is_action_just_pressed("confirm"):
				start_game()
		State.GAME_OVER, State.VICTORY:
			if Input.is_action_just_pressed("confirm"):
				state = State.MENU
		State.LEVEL_DONE:
			update_particles(dt)
			if Input.is_action_just_pressed("confirm"):
				level += 1
				if level >= 3:
					state = State.VICTORY
				else:
					build_level()
					state = State.PLAY
		State.PLAY:
			msg_timer = maxf(0.0, msg_timer - dt)
			update_player(dt)
			update_enemies(dt)
			update_bullets(dt)
			update_particles(dt)
			update_hack(dt)
			# cámara
			var tx := clampf(pl_pos.x + facing * 80.0, SW / 2.0, level_w - SW / 2.0)
			cam_x += (tx - cam_x) * minf(1.0, dt * 5.0)
			camera.position = Vector2(cam_x, 400.0)
			if hp <= 0.0:
				state = State.GAME_OVER


func update_player(dt: float) -> void:
	var move := Input.get_axis("move_left", "move_right")
	cloak_lock = maxf(0.0, cloak_lock - dt)
	invul = maxf(0.0, invul - dt)
	shoot_cd = maxf(0.0, shoot_cd - dt)

	# sigilo (casco): consume energía
	var want_cloak := Input.is_action_pressed("cloak")
	if want_cloak and energy > 1.0 and cloak_lock <= 0.0:
		cloak = true
		energy -= 22.0 * dt
	else:
		cloak = false
		energy = minf(100.0, energy + 14.0 * dt)

	var speed := 150.0 if cloak else 280.0
	pl_vel.x = move * speed
	if move != 0.0:
		facing = 1 if move > 0.0 else -1
		anim += dt * 12.0

	if Input.is_action_just_pressed("jump") and on_ground:
		pl_vel.y = -680.0
		on_ground = false
	pl_vel.y += GRAVITY * dt

	pl_pos.x = clampf(pl_pos.x + pl_vel.x * dt, 30.0, level_w - 30.0)
	var prev := pl_pos.y
	pl_pos.y += pl_vel.y * dt
	on_ground = false
	for r: Rect2 in plats:
		if pl_vel.y >= 0.0 and prev <= r.position.y + 1.0 and pl_pos.y >= r.position.y \
				and pl_pos.x > r.position.x - 12.0 and pl_pos.x < r.end.x + 12.0:
			if Input.is_action_pressed("drop") and r.position.y < GROUND_Y - 1.0:
				continue   # bajar de las plataformas con S
			pl_pos.y = r.position.y
			pl_vel.y = 0.0
			on_ground = true

	# disparo de virus (J o clic izquierdo)
	var shoot := Input.is_action_pressed("shoot")
	if shoot and shoot_cd <= 0.0 and not cloak:
		var from := Vector2(pl_pos.x + facing * 24.0, pl_pos.y - 62.0)
		var to := Vector2(from.x + facing * 100.0, from.y)
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT):
			to = get_global_mouse_position()
		if to.x > from.x:
			facing = 1
		elif to.x < from.x:
			facing = -1
		fire(from, to, true, 760.0)
		shoot_cd = 0.22
	elif shoot and cloak:
		# disparar rompe el sigilo
		cloak = false
		cloak_lock = 0.9


func update_enemies(dt: float) -> void:
	for e: Enemy in enemies:
		if not e.alive:
			continue
		e.phase += dt
		e.flash = maxf(0.0, e.flash - dt)
		if e.infected:
			e.inf_time -= dt
			if e.inf_time <= 0.0:
				e.alive = false
				score += 150
				burst(e_center(e), 24, Color8(90, 255, 140))
				continue

		# movimiento
		if e.t != EType.TURRET:
			var sees_p := (not e.infected) and can_see(e)
			var sp := 55.0 if e.t == EType.GUARD else 95.0
			if sees_p and e.t == EType.GUARD:
				sp = 0.0
			e.x += e.dir * sp * dt
			if e.x < e.min_x:
				e.dir = 1
			if e.x > e.max_x:
				e.dir = -1
			if sees_p:
				e.dir = 1 if pl_pos.x > e.x else -1
		if e.t == EType.DRONE:
			e.y = e.base_y + sin(e.phase * 2.2) * 22.0

		# objetivo
		var have_target := false
		var tgt := Vector2.ZERO
		if e.infected:
			var best := 650.0
			for o: Enemy in enemies:
				if o != e and o.alive and not o.infected:
					var d := absf(o.x - e.x)
					if d < best:
						best = d
						tgt = e_center(o)
						have_target = true
		elif can_see(e):
			tgt = Vector2(pl_pos.x, pl_pos.y - 55.0)
			have_target = true

		e.cd -= dt
		if have_target and e.cd <= 0.0:
			var cd_base := 1.2 if e.t == EType.GUARD else (1.7 if e.t == EType.DRONE else 0.9)
			e.cd = cd_base + randf_range(0.0, 0.5)
			if e.t == EType.TURRET:
				e.dir = 1 if tgt.x >= e.x else -1   # la torreta apunta al objetivo
			fire(e_center(e), tgt, e.infected, 430.0 if e.t == EType.TURRET else 360.0)


func update_bullets(dt: float) -> void:
	for b: Bullet in bullets:
		if not b.alive:
			continue
		b.p += b.v * dt
		b.life -= dt
		if b.life <= 0.0 or b.p.y > GROUND_Y + 5.0 or b.p.x < 0.0 or b.p.x > level_w:
			b.alive = false
			continue
		var br := Rect2(b.p.x - 5.0, b.p.y - 5.0, 10.0, 10.0)
		if b.friendly:
			for e: Enemy in enemies:
				if e.alive and not e.infected and br.intersects(e_rect(e)):
					apply_infection(e, 0.5)
					b.alive = false
					break
		elif invul <= 0.0 and br.intersects(p_rect()):
			hp -= 12.0
			invul = 0.9
			b.alive = false
			hack_prog = maxf(0.0, hack_prog - 0.2)
			burst(Vector2(pl_pos.x, pl_pos.y - 60.0), 8, Color8(255, 90, 90))
	bullets = bullets.filter(func(bb: Bullet) -> bool: return bb.alive)


func update_particles(dt: float) -> void:
	for p: Particle in parts:
		p.life -= dt
		p.v.y += 300.0 * dt
		p.p += p.v * dt
	parts = parts.filter(func(pp: Particle) -> bool: return pp.life > 0.0)


func update_hack(dt: float) -> void:
	if hacked:
		hacked_timer += dt
		if hacked_timer > 1.2 and state == State.PLAY:
			state = State.LEVEL_DONE
			score += 500
		return
	if near_terminal() and Input.is_action_pressed("hack"):
		hack_prog += dt / (3.2 + level * 0.6)
		if randi_range(0, 3) == 0:
			burst(Vector2(terminal.x, terminal.y - 70.0), 1, Color8(90, 255, 140))
		if hack_prog >= 1.0:
			hack_prog = 1.0
			hacked = true
			burst(Vector2(terminal.x, terminal.y - 60.0), 60, Color8(90, 255, 140))
	else:
		hack_prog = maxf(0.0, hack_prog - dt * 0.15)
